/**
 * 全国自治体 ごみ分別データベース (municipalities-data.js)
 * 
 * 【全国データの追加・更新方法】
 * 1. 下の `window.INITIAL_MUNICIPALITIES_DATA` に全国各自治体のデータを追加してください。
 * 2. アプリ画面の「全国データ登録・管理」タブから画面操作またはCSV/JSONインポートで追加し、
 *    「municipalities-data.js をダウンロード」ボタンを押すと、このファイル丸ごと自動生成できます！
 */

window.INITIAL_MUNICIPALITIES_DATA = {
  "24202": {
    "id": "24202",
    "prefecture": "三重県",
    "city": "四日市市",
    "zipPrefixes": [
      "510",
      "512"
    ],
    "notes": "収集日の朝8時までに決められた集積所に出してください。指定ごみ袋はありません（中身が見える透明・半透明の袋を使用）。",
    "officialUrl": "https://www.city.yokkaichi.lg.jp/",
    "categories": [
      {
        "id": "burnable",
        "name": "可燃ごみ",
        "color": "#ef4444",
        "icon": "🔥",
        "schedule": "毎週 月・木曜日（地区により火・金）",
        "bagRule": "透明または半透明の袋",
        "description": "生ごみ、紙くず、木くず、汚れの落ちないプラスチック、革製品、ゴム製品など"
      },
      {
        "id": "nonburnable",
        "name": "不燃ごみ",
        "color": "#3b82f6",
        "icon": "🔨",
        "schedule": "月2回（第1・第3水曜日など地区別）",
        "bagRule": "透明または半透明の袋（割れるものは紙に包む）",
        "description": "ガラス製品、陶磁器、小型家電（30cm未満）、金属製品、傘など"
      },
      {
        "id": "plastic",
        "name": "プラスチック製容器包装",
        "color": "#f59e0b",
        "icon": "♻️",
        "schedule": "毎週 水曜日（地区により異なります）",
        "bagRule": "透明または半透明の袋（二重袋不可）",
        "description": "プラマークのあるトレイ、カップ、ポリ袋、ボトル類、発泡スチロール"
      },
      {
        "id": "resource",
        "name": "資源ごみ（缶・びん・ペット・紙）",
        "color": "#10b981",
        "icon": "🍾",
        "schedule": "月2回（地区別収集日）",
        "bagRule": "種類ごとに分けてコンテナ・ひも縛り",
        "description": "空き缶、空きびん、ペットボトル、新聞、雑誌、ダンボール、紙パック、古着"
      },
      {
        "id": "bulky",
        "name": "大型ごみ（粗大ごみ）",
        "color": "#8b5cf6",
        "icon": "🛋️",
        "schedule": "事前申込制（大型ごみ受付センターへ連絡）",
        "bagRule": "大型ごみ処理券を貼付",
        "description": "一辺が30cm以上の家具、寝具、自転車、大型家電など"
      },
      {
        "id": "hazardous",
        "name": "有害ごみ",
        "color": "#ec4899",
        "icon": "🔋",
        "schedule": "不燃ごみと同日（別袋で出す）",
        "bagRule": "透明の小さな袋に入れて別出し",
        "description": "乾電池、蛍光管、水銀体温計、ライター、スプレー缶（使い切る）"
      }
    ],
    "items": [
      {
        "name": "ペットボトル",
        "kana": "ぺっとぼとる",
        "categoryId": "resource",
        "note": "キャップとラベルを外し（プラ製容器包装へ）、中を水洗いしてつぶして出してください。",
        "keywords": [
          "飲料",
          "お茶",
          "ジュース",
          "PET"
        ]
      },
      {
        "name": "食品トレイ（発泡スチロール）",
        "kana": "しょくひんとれい",
        "categoryId": "plastic",
        "note": "軽く水洗いして汚れを落としてください。汚れが落ちないものは可燃ごみへ。",
        "keywords": [
          "肉トレイ",
          "魚トレイ",
          "プラ"
        ]
      },
      {
        "name": "生ごみ（野菜くず・残飯）",
        "kana": "なまごみ",
        "categoryId": "burnable",
        "note": "水気をよく切ってから透明・半透明の袋に入れて出してください。",
        "keywords": [
          "料理くず",
          "果物の皮",
          "茶殻"
        ]
      },
      {
        "name": "乾電池（アルカリ・マンガン）",
        "kana": "かんでんち",
        "categoryId": "hazardous",
        "note": "不燃ごみの日に、他のごみと混ぜずに透明な袋に入れて出してください。充電式電池は回収協力店へ。",
        "keywords": [
          "電池",
          "単3",
          "単4"
        ]
      },
      {
        "name": "スプレー缶・カセットボンベ",
        "kana": "すぷれーかん",
        "categoryId": "hazardous",
        "note": "必ず火気のない屋外で中身を完全に使い切ってから、穴を開けずに有害ごみへ。",
        "keywords": [
          "ガス缶",
          "ヘアスプレー",
          "殺虫剤"
        ]
      },
      {
        "name": "ダンボール",
        "kana": "だんぼーる",
        "categoryId": "resource",
        "note": "折りたたんでひもで十文字に縛って出してください。雨の日は避けてください。",
        "keywords": [
          "段ボール",
          "梱包箱"
        ]
      },
      {
        "name": "フライパン・なべ",
        "kana": "ふらいぱん",
        "categoryId": "nonburnable",
        "note": "30cm未満のものは不燃ごみへ。30cm以上のものは大型ごみになります。",
        "keywords": [
          "鍋",
          "調理器具",
          "金属"
        ]
      },
      {
        "name": "傘（ビニール傘・折りたたみ傘）",
        "kana": "かさ",
        "categoryId": "nonburnable",
        "note": "そのまま不燃ごみとして出せます（長さがはみ出る場合は袋から出ても可）。",
        "keywords": [
          "雨傘",
          "日傘"
        ]
      },
      {
        "name": "ソファ・タンス・ベッド",
        "kana": "そふぁ",
        "categoryId": "bulky",
        "note": "事前に四日市市大型ごみ受付センターへ電話またはWebで申し込み、処理券を貼ってください。",
        "keywords": [
          "家具",
          "大型家具",
          "マットレス"
        ]
      },
      {
        "name": "レジ袋・お菓子の袋",
        "kana": "れじぶくろ",
        "categoryId": "plastic",
        "note": "プラマークがあるものはプラスチック製容器包装へ。汚れている場合は可燃ごみへ。",
        "keywords": [
          "ビニール袋",
          "包装フィルム"
        ]
      },
      {
        "name": "蛍光管・電球",
        "kana": "けいこうかん",
        "categoryId": "hazardous",
        "note": "蛍光管は割れないように購入時の箱や紙に包んで有害ごみへ。LED電球・白熱電球は不燃ごみへ。",
        "keywords": [
          "蛍光灯",
          "ランプ"
        ]
      },
      {
        "name": "食用油（てんぷら油）",
        "kana": "しょくようあぶら",
        "categoryId": "burnable",
        "note": "凝固剤で固めるか、新聞紙・布に染み込ませて可燃ごみへ出してください。",
        "keywords": [
          "サラダ油",
          "廃油"
        ]
      }
    ]
  },
  "24205": {
    "id": "24205",
    "prefecture": "三重県",
    "city": "桑名市",
    "zipPrefixes": [
      "511"
    ],
    "notes": "収集日の朝8時30分までに集積所へ出してください。燃やせるごみ・燃やせないごみは市指定ごみ袋が必要です。",
    "officialUrl": "https://www.city.kuwana.lg.jp/",
    "categories": [
      {
        "id": "burnable",
        "name": "燃やせるごみ",
        "color": "#ef4444",
        "icon": "🔥",
        "schedule": "毎週 月・木曜日 または 火・金曜日",
        "bagRule": "桑名市指定ごみ袋（燃やせるごみ用・赤文字）",
        "description": "生ごみ、紙くず、布類、木くず、汚れの落ちないプラスチックなど"
      },
      {
        "id": "nonburnable",
        "name": "燃やせないごみ",
        "color": "#3b82f6",
        "icon": "🔨",
        "schedule": "月2回（地区別水曜日）",
        "bagRule": "桑名市指定ごみ袋（燃やせないごみ用・青文字）",
        "description": "金属類、ガラス、陶磁器、小型家電製品など"
      },
      {
        "id": "plastic",
        "name": "プラスチック製容器包装",
        "color": "#f59e0b",
        "icon": "♻️",
        "schedule": "毎週 水曜日",
        "bagRule": "無色透明の袋",
        "description": "プラマークの付いたトレイ、ボトル、袋、カップ類"
      },
      {
        "id": "resource",
        "name": "資源ごみ",
        "color": "#10b981",
        "icon": "🍾",
        "schedule": "月2回（地区別収集日）",
        "bagRule": "種類ごとにコンテナ・ひも縛り",
        "description": "空き缶、空きびん、ペットボトル、古紙類、乾電池"
      },
      {
        "id": "bulky",
        "name": "粗大ごみ",
        "color": "#8b5cf6",
        "icon": "🛋️",
        "schedule": "事前予約制（戸別有料収集）",
        "bagRule": "粗大ごみ処理券を貼付",
        "description": "指定袋に入らない大きさの家具・家電・自転車など"
      }
    ],
    "items": [
      {
        "name": "ペットボトル",
        "kana": "ぺっとぼとる",
        "categoryId": "resource",
        "note": "キャップ・ラベルを外し、水洗いして資源ごみの日に出してください。",
        "keywords": [
          "飲料",
          "PET"
        ]
      },
      {
        "name": "生ごみ",
        "kana": "なまごみ",
        "categoryId": "burnable",
        "note": "しっかり水切りをして、市指定の燃やせるごみ袋に入れてください。",
        "keywords": [
          "野菜くず",
          "残飯"
        ]
      },
      {
        "name": "食品トレイ",
        "kana": "しょくひんとれい",
        "categoryId": "plastic",
        "note": "軽く洗って無色透明の袋に入れて出してください。",
        "keywords": [
          "プラ",
          "パック"
        ]
      },
      {
        "name": "乾電池",
        "kana": "かんでんち",
        "categoryId": "resource",
        "note": "資源ごみの日に透明な小袋に入れて出してください。",
        "keywords": [
          "電池"
        ]
      }
    ]
  },
  "13113": {
    "id": "13113",
    "prefecture": "東京都",
    "city": "渋谷区",
    "zipPrefixes": [
      "150",
      "151"
    ],
    "notes": "収集日の朝8時までに出してください。中身の見える透明または半透明の袋を使用してください。",
    "officialUrl": "https://www.city.shibuya.tokyo.jp/",
    "categories": [
      {
        "id": "burnable",
        "name": "可燃ごみ",
        "color": "#ef4444",
        "icon": "🔥",
        "schedule": "週2回（地区別）",
        "bagRule": "透明・半透明の袋",
        "description": "生ごみ、プラスチック類、ゴム・皮革製品、紙くず、衣類"
      },
      {
        "id": "nonburnable",
        "name": "不燃ごみ",
        "color": "#3b82f6",
        "icon": "🔨",
        "schedule": "月2回（地区別）",
        "bagRule": "透明・半透明の袋",
        "description": "金属類、ガラス、陶磁器、小型家電（30cm角未満）、乾電池、スプレー缶"
      },
      {
        "id": "resource",
        "name": "資源（びん・缶・ペット・古紙）",
        "color": "#10b981",
        "icon": "♻️",
        "schedule": "週1回（地区別）",
        "bagRule": "種類ごとに透明袋またはコンテナ",
        "description": "びん、缶、ペットボトル、新聞、雑誌、ダンボール、紙パック"
      },
      {
        "id": "bulky",
        "name": "粗大ごみ",
        "color": "#8b5cf6",
        "icon": "🛋️",
        "schedule": "事前申込制（粗大ごみ受付センター）",
        "bagRule": "有料粗大ごみ処理券を貼付",
        "description": "一辺の長さが30cmを超える家具・寝具・家電など"
      }
    ],
    "items": [
      {
        "name": "プラスチック製容器包装・プラ製品",
        "kana": "ぷらすちっく",
        "categoryId": "burnable",
        "note": "渋谷区では汚れのついたプラやプラスチック製品は可燃ごみとして収集します。",
        "keywords": [
          "トレイ",
          "レジ袋",
          "プラ"
        ]
      },
      {
        "name": "ペットボトル",
        "kana": "ぺっとぼとる",
        "categoryId": "resource",
        "note": "キャップ・ラベルを外し（可燃ごみへ）、中をすすいでつぶして資源の日へ。",
        "keywords": [
          "飲料",
          "PET"
        ]
      },
      {
        "name": "スプレー缶・乾電池",
        "kana": "すぷれーかん",
        "categoryId": "nonburnable",
        "note": "中身を使い切り、他の不燃ごみとは別の透明袋に入れて出してください。",
        "keywords": [
          "ガス缶",
          "電池"
        ]
      }
    ]
  },
  "27100": {
    "id": "27100",
    "prefecture": "大阪府",
    "city": "大阪市",
    "zipPrefixes": [
      "530",
      "540",
      "550"
    ],
    "notes": "収集日の朝9時までに決められた場所へ出してください。中身の見える透明・半透明の袋を使用してください。",
    "officialUrl": "https://www.city.osaka.lg.jp/",
    "categories": [
      {
        "id": "burnable",
        "name": "普通ごみ",
        "color": "#ef4444",
        "icon": "🔥",
        "schedule": "週2回（地区別）",
        "bagRule": "透明・半透明の袋",
        "description": "生ごみ、紙くず、木くず、金属・ガラス・陶磁器、汚れのあるプラスチックなど"
      },
      {
        "id": "resource",
        "name": "資源ごみ（缶・びん・ペット・金属製調理用具）",
        "color": "#10b981",
        "icon": "🍾",
        "schedule": "週1回（地区別）",
        "bagRule": "透明・半透明の袋",
        "description": "空き缶、空きびん、ペットボトル、金属製のなべ・やかん・フライパン"
      },
      {
        "id": "plastic",
        "name": "容器包装プラスチック",
        "color": "#f59e0b",
        "icon": "♻️",
        "schedule": "週1回（地区別）",
        "bagRule": "透明・半透明の袋",
        "description": "プラマークのあるトレイ、カップ、ボトル、ポリ袋、緩衝材"
      },
      {
        "id": "paper",
        "name": "古紙・衣類",
        "color": "#06b6d4",
        "icon": "📰",
        "schedule": "週1回（地区別）",
        "bagRule": "ひもで十文字に縛る／透明袋",
        "description": "新聞、雑誌、ダンボール、紙パック、衣類"
      },
      {
        "id": "bulky",
        "name": "粗大ごみ",
        "color": "#8b5cf6",
        "icon": "🛋️",
        "schedule": "事前申込制（粗大ごみ収集受付センター）",
        "bagRule": "粗大ごみ処理手数料券を貼付",
        "description": "最大の辺または径が30cmを超えるもの、あるいは棒状で1mを超えるもの"
      }
    ],
    "items": [
      {
        "name": "ペットボトル",
        "kana": "ぺっとぼとる",
        "categoryId": "resource",
        "note": "キャップ・ラベルを外し（容器包装プラへ）、軽く水洗いして資源ごみの日に出してください。",
        "keywords": [
          "PET",
          "飲料"
        ]
      },
      {
        "name": "なべ・フライパン・やかん",
        "kana": "なべ",
        "categoryId": "resource",
        "note": "大阪市では金属製調理用具は資源ごみとして収集します。",
        "keywords": [
          "鍋",
          "調理器具"
        ]
      },
      {
        "name": "陶磁器・ガラスコップ",
        "kana": "とうじき",
        "categoryId": "burnable",
        "note": "紙などに包んでキケンと表示し、普通ごみの日に出してください。",
        "keywords": [
          "皿",
          "割れ物"
        ]
      }
    ]
  },
  "23100": {
    "id": "23100",
    "prefecture": "愛知県",
    "city": "名古屋市",
    "zipPrefixes": [
      "450",
      "460"
    ],
    "notes": "収集日の朝8時（中区の一部は7時30分）までに指定袋に入れて出してください。",
    "officialUrl": "https://www.city.nagoya.jp/",
    "categories": [
      {
        "id": "burnable",
        "name": "可燃ごみ",
        "color": "#ef4444",
        "icon": "🔥",
        "schedule": "週2回（地区別）",
        "bagRule": "名古屋市指定可燃ごみ袋",
        "description": "生ごみ、紙くず、木くず、革・ゴム製品、汚れの落ちないプラスチック"
      },
      {
        "id": "nonburnable",
        "name": "不燃ごみ",
        "color": "#3b82f6",
        "icon": "🔨",
        "schedule": "月1回（地区別）",
        "bagRule": "名古屋市指定不燃ごみ袋",
        "description": "金属製品、ガラス、陶磁器、小型家電など"
      },
      {
        "id": "plastic",
        "name": "プラスチック製容器包装",
        "color": "#f59e0b",
        "icon": "♻️",
        "schedule": "週1回（地区別）",
        "bagRule": "名古屋市指定プラスチック製容器包装袋",
        "description": "プラマークのついたトレイ、カップ、ポリ袋、ボトル類"
      },
      {
        "id": "resource",
        "name": "空きびん・空き缶・ペットボトル",
        "color": "#10b981",
        "icon": "🍾",
        "schedule": "週1回（地区別）",
        "bagRule": "種類ごとに指定の回収容器・ネットへ",
        "description": "飲料・食品用の空きびん、空き缶、ペットボトル"
      }
    ],
    "items": [
      {
        "name": "ペットボトル",
        "kana": "ぺっとぼとる",
        "categoryId": "resource",
        "note": "キャップとラベルを外し（プラ製容器包装へ）、水洗いして回収容器へ入れてください。",
        "keywords": [
          "飲料",
          "PET"
        ]
      },
      {
        "name": "生ごみ",
        "kana": "なまごみ",
        "categoryId": "burnable",
        "note": "水気をよく切って名古屋市指定の可燃ごみ袋に入れて出してください。",
        "keywords": [
          "野菜くず",
          "残飯"
        ]
      }
    ]
  }
};
